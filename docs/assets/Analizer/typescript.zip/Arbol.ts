var parser = require('./coline');
var Clase = require('./Clase');
var Operacion = require('./Operacion');
var Funcion = require('./Funcion.js');
import If from './If'
var fs = require('fs');
var source = fs.readFileSync('./entrada.txt', 'utf8');
var ast;
try {
    //var identi = new Funcion("var1_delta");
    //console.log(identi.Obtenerid());
    //console.log(1>3 ? "Hola" : "Fuck You");
    ast = parser.parse(source);
    //console.log(ast.length);
    //console.log(ast);

    for (let index = 0; index < ast.length; index++) {
        const element = ast[index];
        element.ejecutar();
        console.log(element.constructor.name);
        
    }
   
    
}
catch (exception) {
    console.log("Parse Error: " + exception.message);
}

