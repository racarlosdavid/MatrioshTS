import Instruccion from './Instruccion'

class Clase implements Instruccion{
    public modificadores:[];
    public id:String;
    public idextends:String;
    public listainstrucciones:Instruccion[];


    constructor(modificadores:[],id:String,idextends:String,listainstrucciones:[]){
        this.modificadores = modificadores;
        this.id = id;
        this.idextends = idextends;
        this.listainstrucciones = listainstrucciones;
    }

    ejecutar() {
        for (let index = 0; index < this.listainstrucciones.length; index++) {
            const element = this.listainstrucciones[index];
            element.ejecutar();
        }
        return null;
    }

}
module.exports = Clase;