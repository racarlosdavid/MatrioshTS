class Data{
    private id:String;
    constructor(id){
        this.id = id;
    }
    getI(){
        if (1>3) {
            return "hola";
        } else {
            return null;
            
        }
    }
}
module.exports = Data;