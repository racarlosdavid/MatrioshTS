import Instruccion from './Instruccion'

class Funcion implements Instruccion {
    private id:String;

    constructor(id:String){
        this.id = id;

    }
    ejecutar(): Object {
        throw new Error("Method not implemented.");
    }
    Obtenerid():String{
        return this.id;
    }   
}
module.exports = Funcion;