import Instruccion from './Instruccion'

export default class If implements Instruccion{
  
    private  valorCondicion:Boolean;
  
    private   isElse:boolean;

    private   isElseIf:boolean;

    private   condicion:Instruccion;

    private   listaInstrucciones:Instruccion[];

    private   listaelseif: [];

    private   listaelse:Instruccion[];

    constructor(condicion:Instruccion, listaintrucciones:[],listaelseif:[],listaelse:[],isElse:boolean,isElseIf:boolean){
        this.condicion = condicion;
        this.listaInstrucciones = listaintrucciones;
        this.listaelseif=listaelseif;
        this.listaelse = listaelse;
        this.isElse = isElse;
        this.isElseIf = isElseIf;
    }
    getF(){
        console.log("HELL YEAH");
    }
    ejecutar() {
        if (this.condicion.ejecutar()) {
            for (let index = 0; index < this.listaInstrucciones.length; index++) {
                const element = this.listaInstrucciones[index];
                var r = element.ejecutar();
                        if (r!=null) {
                            return r;
                        }  
                
            }
           
        } else if (this.isElseIf) {
           
            for (let index = 0; index < this.listaelseif.length; index++) {
                const element = this.listaelseif[index];
                var condicion1:Instruccion = element[0];
                var istrucciones1:[] = element[1];
                if (condicion1.ejecutar()) {
                    for (let index = 0; index < istrucciones1.length; index++) {
                        const element1:Instruccion = istrucciones1[index];
                        var r = element1.ejecutar();
                        if (r!=null) {
                            return r;
                        }  
                    }
                
                }
            }
                
            if (this.isElse) {
               
                for (let index = 0; index < this.listaelse.length; index++) {
                    const element = this.listaelse[index];
                    var r = element.ejecutar();
                        if (r!=null) {
                            return r;
                        }      
                }
                
            }
                
                
        } else if (this.isElse) {
            for (let index = 0; index < this.listaelse.length; index++) {
                const element = this.listaelse[index];
                var r = element.ejecutar();
                        if (r!=null) {
                            return r;
                        }  
            }
        
        }else {
            return null;
        }

        
    }
}
module.exports = If;