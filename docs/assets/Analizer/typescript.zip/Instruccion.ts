export default interface Instruccion {
    ejecutar():Object;
}