import Instruccion from './Instruccion'

class Operacion implements Instruccion {


    private operacion:String;

    private operadorIzq:Operacion;

    private operadorDer:Operacion;
            
    private valor:Object;
    
    private tipo:String;

    constructor( operadorIzq:Operacion,  operadorDer:Operacion,  operacion:String, a:Object, tipo:String) {
        this.operacion = operacion;
        this.operadorIzq = operadorIzq;
        this.operadorDer = operadorDer;
        this.valor = a;
        this.tipo = tipo;
    }
  
    ejecutar() {
        var val1 = (this.operadorIzq == null) ? null : this.operadorIzq.ejecutar();
        var val2 = (this.operadorDer == null) ? null : this.operadorDer.ejecutar();
 
        switch (this.operacion) {
            case '+':
                return val1 + val2;
            case '-':
                return val1 - val2;
            case '*':
                return val1 * val2;
            case '/':
                return val1 / val2;
            case '^':
                return Math.pow(val1,val2);
            case 'uminus':
                return val2 * -1;
            case 'numero':
                return Number(this.valor);
            case 'cadena':
                return this.valor.toString;
            case 'id':
                return this.valor.toString;
            case '>':
                return val1 > val2;
            case '<':
                return val1 < val2;
            default:
                break;
        }
        return null; 
    }

}
module.exports = Operacion;