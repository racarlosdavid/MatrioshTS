import Instruccion from './Instruccion'

class Print implements Instruccion{

    private contenido:Instruccion;
    
    constructor(contenido:Instruccion){
        this.contenido = contenido;
    }

    ejecutar(): Object {
        try {
            console.log("> "+this.contenido.ejecutar());
        } catch (error) {
            return null;
        }
        return null;
    }


}
module.exports = Print;