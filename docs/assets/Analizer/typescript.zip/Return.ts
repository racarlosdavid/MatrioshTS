import Instruccion from './Instruccion'

class Return implements Instruccion{

    private valorRetorno:Instruccion;
    
    constructor(valorRetorno:Instruccion){
        this.valorRetorno = valorRetorno;
    }
    
    ejecutar(): Object {
        if(this.valorRetorno==null){
            return this;
        }else{
            return this.valorRetorno.ejecutar();
        }
    }


}
module.exports = Return;